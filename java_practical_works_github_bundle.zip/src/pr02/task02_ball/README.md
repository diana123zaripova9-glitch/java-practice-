# task02_ball

Решение задания в отдельных Java-файлах. Откройте класс с методом `main` и запустите его в IntelliJ IDEA.

Запуск из терминала:
```bash
javac *.java
java TestBall
```
