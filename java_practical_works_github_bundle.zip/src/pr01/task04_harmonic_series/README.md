# task04_harmonic_series

Решение задания в отдельных Java-файлах. Откройте класс с методом `main` и запустите его в IntelliJ IDEA.

Запуск из терминала:
```bash
javac *.java
java Main
```
